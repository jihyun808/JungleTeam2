
// 간단한 더미 일정 데이터 (필요시 API 연동으로 교체 가능)
const games = [
  { date: '2025-08-16', time: '18:30', home: 'LG 트윈스', away: '두산 베어스', stadium: '잠실' },
  { date: '2025-08-16', time: '18:30', home: '롯데 자이언츠', away: 'KIA 타이거즈', stadium: '사직' },
  { date: '2025-08-17', time: '18:30', home: '삼성 라이온즈', away: 'NC 다이노스', stadium: '대구' },
  { date: '2025-08-17', time: '18:30', home: 'SSG 랜더스', away: 'KT 위즈', stadium: '문학' },
  { date: '2025-08-18', time: '18:30', home: '키움 히어로즈', away: '한화 이글스', stadium: '고척' }
];

function render(list) {
  const box = document.getElementById('scheduleList');
  if (!box) return;
  box.innerHTML = '';
  list.forEach(g => {
    const card = document.createElement('div');
    card.className = 'bg-white border rounded-xl p-4 flex flex-col gap-2';
    card.innerHTML = `
      <div class="text-sm text-gray-500">${g.date} ${g.time}</div>
      <div class="font-semibold">${g.home} vs ${g.away}</div>
      <div class="text-sm text-gray-600">구장: ${g.stadium}</div>
      <button class="mt-2 inline-flex items-center justify-center rounded-lg bg-blue-600 text-white px-3 py-2 hover:bg-blue-700">
        예매하기
      </button>
    `;
    card.querySelector('button').addEventListener('click', () => {
      alert('좌석 선택 페이지로 이동합니다 (데모)');
    });
    box.appendChild(card);
  });
}

function applyFilters() {
  const team = document.getElementById('teamFilter').value;
  const stadium = document.getElementById('stadiumFilter').value;
  const date = document.getElementById('dateFilter').value;
  let filtered = games.slice();
  if (team) filtered = filtered.filter(g => g.home===team || g.away===team);
  if (stadium) filtered = filtered.filter(g => g.stadium===stadium);
  if (date) filtered = filtered.filter(g => g.date===date);
  render(filtered);
}

document.addEventListener('DOMContentLoaded', () => {
  render(games);
  ['teamFilter','stadiumFilter','dateFilter'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('change', applyFilters);
  });
  const reset = document.getElementById('resetFilters');
  if (reset) reset.addEventListener('click', () => {
    ['teamFilter','stadiumFilter','dateFilter'].forEach(id => {
      const el = document.getElementById(id);
      if (el.tagName.toLowerCase()==='select') el.selectedIndex = 0;
      if (el.tagName.toLowerCase()==='input') el.value = '';
    });
    render(games);
  });
});
