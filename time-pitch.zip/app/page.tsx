"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Calendar,
  Trophy,
  Users,
  Newspaper,
  Ticket,
  ExternalLink,
  ChevronLeft,
  ChevronRight,
  User,
  LogIn,
} from "lucide-react"
import { useEffect, useState } from "react"
import Link from "next/link"

interface TeamRanking {
  rank: number
  team: string
  wins: number
  losses: number
  draws: number
  games: number
  winRate: number
}

interface PlayerStat {
  name: string
  team: string
  position: string
  avg?: number
  hr?: number
  rbi?: number
  sb?: number
  wins?: number
  losses?: number
  era?: number
  strikeouts?: number
}

interface Game {
  id: number
  home: string
  away: string
  time: string
  stadium: string
  date: string
  status: string
  ticketAvailable: boolean
}

interface NewsItem {
  id: number
  title: string
  summary: string
  publishedAt: string
  source: string
  url: string
  imageUrl: string
}

export default function HomePage() {
  const [teamRankings, setTeamRankings] = useState<TeamRanking[]>([])
  const [playerStats, setPlayerStats] = useState<PlayerStat[]>([])
  const [todayGames, setTodayGames] = useState<Game[]>([])
  const [news, setNews] = useState<NewsItem[]>([])
  const [loading, setLoading] = useState(true)
  const [currentBanner, setCurrentBanner] = useState(0)

  const banners = [
    {
      id: 1,
      title: "암표 없는 공정한 예매",
      subtitle: "구역별 3분 간격 시스템으로 모든 팬에게 공평한 기회를",
      description:
        "Time-Pitch는 티켓 암표와 몰림 현상을 방지하여 진정한 야구 팬들이 공정하게 티켓을 구매할 수 있도록 합니다.",
      image: "/baseball-stadium-ticketing.png",
      bgColor: "from-blue-600 to-indigo-700",
    },
    {
      id: 2,
      title: "혁신적인 구역별 예매 시스템",
      subtitle: "3분 간격으로 순차 오픈되는 스마트한 티켓팅",
      description: "각 구역마다 3분씩 시차를 두고 예매를 시작하여 서버 과부하와 불공정한 경쟁을 원천 차단합니다.",
      image: "/digital-baseball-ticket-system.png",
      bgColor: "from-green-600 to-teal-700",
    },
    {
      id: 3,
      title: "진짜 팬을 위한 티켓팅",
      subtitle: "암표상 OUT! 공정한 예매 IN!",
      description:
        "실시간 모니터링과 AI 기반 이상 거래 탐지로 암표상의 불법 행위를 차단하고 진정한 야구 팬들을 보호합니다.",
      image: "/celebrating-baseball-fans.png",
      bgColor: "from-red-600 to-pink-700",
    },
  ]

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [teamsRes, playersRes, gamesRes, newsRes] = await Promise.all([
          fetch("/api/teams/rankings"),
          fetch("/api/players/stats?category=batting"),
          fetch("/api/games/today"),
          fetch("/api/news?limit=3"),
        ])

        const [teamsData, playersData, gamesData, newsData] = await Promise.all([
          teamsRes.json(),
          playersRes.json(),
          gamesRes.json(),
          newsRes.json(),
        ])

        if (teamsData.success) setTeamRankings(teamsData.data.slice(0, 5))
        if (playersData.success) setPlayerStats(playersData.data.slice(0, 5))
        if (gamesData.success) setTodayGames(gamesData.data.slice(0, 5))
        if (newsData.success) setNews(newsData.data)
      } catch (error) {
        console.error("Failed to fetch data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentBanner((prev) => (prev + 1) % banners.length)
    }, 6000) // 6초마다 자동 슬라이드

    return () => clearInterval(timer)
  }, [banners.length])

  const formatTimeAgo = (dateString: string) => {
    const now = new Date()
    const publishedDate = new Date(dateString)
    const diffInHours = Math.floor((now.getTime() - publishedDate.getTime()) / (1000 * 60 * 60))

    if (diffInHours < 1) return "방금 전"
    if (diffInHours < 24) return `${diffInHours}시간 전`
    const diffInDays = Math.floor(diffInHours / 24)
    return `${diffInDays}일 전`
  }

  const nextBanner = () => {
    setCurrentBanner((prev) => (prev + 1) % banners.length)
  }

  const prevBanner = () => {
    setCurrentBanner((prev) => (prev - 1 + banners.length) % banners.length)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header Navigation */}
      <header className="border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                <Ticket className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-blue-600">Time-Pitch</h1>
            </div>
            <nav className="flex items-center space-x-6">
              <Link href="/booking" className="text-gray-600 hover:text-blue-600 transition-colors font-medium">
                예매
              </Link>
              <Button variant="outline" className="flex items-center gap-2 bg-transparent">
                <LogIn className="w-4 h-4" />
                로그인
              </Button>
              <Button variant="ghost" className="flex items-center gap-2">
                <User className="w-4 h-4" />
                마이페이지
              </Button>
            </nav>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* 왼쪽 사이드바 */}
        <aside className="w-64 bg-gray-50 min-h-screen p-4 border-r">
          <div className="space-y-6">
            {/* 구단 순위 */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Trophy className="w-4 h-4 text-yellow-500" />
                  구단 순위
                </CardTitle>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="space-y-2">
                    {[...Array(5)].map((_, i) => (
                      <div key={i} className="animate-pulse bg-gray-200 h-12 rounded"></div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-2">
                    {teamRankings.map((team) => (
                      <div key={team.rank} className="p-2 bg-white rounded border text-sm">
                        <div className="flex items-center gap-2">
                          <Badge variant="secondary" className="text-xs">
                            {team.rank}
                          </Badge>
                          <span className="font-medium text-xs">{team.team}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* 구간 순서 */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">구간 순서</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="p-2 bg-blue-100 rounded text-sm font-medium text-blue-800">1구역 (14:00)</div>
                <div className="p-2 bg-gray-100 rounded text-sm">2구역 (14:03)</div>
                <div className="p-2 bg-gray-100 rounded text-sm">3구역 (14:06)</div>
                <div className="p-2 bg-gray-100 rounded text-sm">4구역 (14:09)</div>
              </CardContent>
            </Card>

            {/* 선수 순위 */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  선수 순위
                </CardTitle>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="space-y-2">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="animate-pulse bg-gray-200 h-12 rounded"></div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-2">
                    {playerStats.slice(0, 3).map((player, index) => (
                      <div key={index} className="p-2 bg-white rounded border text-sm">
                        <div className="font-medium">{player.name}</div>
                        <div className="text-xs text-gray-500">
                          {player.team} • {player.avg?.toFixed(3)}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </aside>

        {/* 메인 콘텐츠 */}
        <main className="flex-1">
          {/* 배너 섹션 */}
          <section className="relative overflow-hidden">
            <div className="relative h-[400px]">
              {banners.map((banner, index) => (
                <div
                  key={banner.id}
                  className={`absolute inset-0 transition-transform duration-1000 ease-in-out ${
                    index === currentBanner
                      ? "translate-x-0"
                      : index < currentBanner
                        ? "-translate-x-full"
                        : "translate-x-full"
                  }`}
                >
                  <div className={`h-full bg-gradient-to-r ${banner.bgColor} text-white relative`}>
                    <div className="absolute inset-0 bg-black/20"></div>
                    <div
                      className="absolute inset-0 bg-cover bg-center opacity-30"
                      style={{ backgroundImage: `url(${banner.image})` }}
                    ></div>
                    <div className="relative z-10 container mx-auto px-4 h-full flex items-center">
                      <div className="max-w-2xl">
                        <h2 className="text-4xl md:text-5xl font-bold mb-4 leading-tight">{banner.title}</h2>
                        <p className="text-lg md:text-xl mb-4 opacity-90">{banner.subtitle}</p>
                        <p className="text-base mb-6 opacity-80 leading-relaxed">{banner.description}</p>
                        <Link href="/booking">
                          <Button size="lg" className="bg-white text-gray-900 hover:bg-gray-100 font-semibold">
                            <Calendar className="w-5 h-5 mr-2" />
                            지금 예매하기
                          </Button>
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* 배너 네비게이션 */}
            <button
              onClick={prevBanner}
              className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/20 hover:bg-white/30 text-white p-2 rounded-full transition-colors z-20"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <button
              onClick={nextBanner}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/20 hover:bg-white/30 text-white p-2 rounded-full transition-colors z-20"
            >
              <ChevronRight className="w-6 h-6" />
            </button>

            {/* 배너 인디케이터 */}
            <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex space-x-2 z-20">
              {banners.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentBanner(index)}
                  className={`w-3 h-3 rounded-full transition-colors ${
                    index === currentBanner ? "bg-white" : "bg-white/50"
                  }`}
                />
              ))}
            </div>
          </section>

          {/* 예매창 섹션 */}
          <section className="p-6 bg-white border-b">
            <h2 className="text-2xl font-bold mb-4">오늘의 경기 예매</h2>
            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="animate-pulse bg-gray-200 h-32 rounded-lg"></div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                {todayGames.map((game) => (
                  <Card key={game.id} className="border-2 hover:border-blue-300 transition-colors cursor-pointer">
                    <CardContent className="p-4 h-52 flex flex-col">
                      <div className="text-center flex-1 flex flex-col justify-center space-y-1">
                        <div className="text-sm text-gray-500">{game.time}</div>
                        <div className="font-bold text-base">{game.away}</div>
                        <div className="text-sm text-gray-600">vs</div>
                        <div className="font-bold text-base">{game.home}</div>
                        <div className="text-xs text-gray-600 mt-1">{game.stadium}</div>
                      </div>
                      <div className="mt-auto pt-3">
                        <Link href="/booking">
                          <Button className="w-full bg-blue-600 hover:bg-blue-700" disabled={!game.ticketAvailable}>
                            {game.ticketAvailable ? "예매하기" : "매진"}
                          </Button>
                        </Link>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </section>

          {/* 기수/이유 섹션 (뉴스) */}
          <section className="p-6">
            <div className="max-w-4xl">
              {/* KBO 뉴스 */}
              <div className="mb-6">
                <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                  <Newspaper className="w-6 h-6 text-red-500" />
                  KBO 뉴스
                </h2>
                {loading ? (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="animate-pulse">
                        <div className="bg-gray-200 h-48 rounded-lg mb-4"></div>
                        <div className="bg-gray-200 h-4 rounded mb-2"></div>
                        <div className="bg-gray-200 h-3 rounded w-3/4"></div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {news.slice(0, 3).map((newsItem) => (
                      <Card
                        key={newsItem.id}
                        className="overflow-hidden hover:shadow-lg transition-all duration-300 cursor-pointer group border-0 shadow-md"
                        onClick={() => window.open(newsItem.url, "_blank")}
                      >
                        <div className="relative h-48 overflow-hidden">
                          <img
                            src={newsItem.imageUrl || "/placeholder.svg"}
                            alt={newsItem.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                          <div className="absolute top-3 left-3">
                            <Badge variant="secondary" className="bg-white/90 text-gray-800 font-medium">
                              {newsItem.source}
                            </Badge>
                          </div>
                          <div className="absolute top-3 right-3">
                            <div className="bg-white/90 rounded-full p-1">
                              <ExternalLink className="w-4 h-4 text-gray-600" />
                            </div>
                          </div>
                        </div>
                        <CardContent className="p-4">
                          <h3 className="font-bold text-lg mb-2 line-clamp-2 group-hover:text-blue-600 transition-colors">
                            {newsItem.title}
                          </h3>
                          <p className="text-gray-600 text-sm mb-3 line-clamp-2">{newsItem.summary}</p>
                          <div className="flex justify-between items-center text-xs text-gray-500">
                            <span>{formatTimeAgo(newsItem.publishedAt)}</span>
                            <span className="text-blue-600 font-medium group-hover:underline">자세히 보기</span>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
                <div className="text-center mt-8">
                  <Link href="/news">
                    <Button
                      variant="outline"
                      className="bg-transparent border-2 hover:bg-blue-50 hover:border-blue-300"
                    >
                      <Newspaper className="w-4 h-4 mr-2" />더 많은 뉴스 보기
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </section>
        </main>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 mt-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                  <Ticket className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-xl font-bold">Time-Pitch</h3>
              </div>
              <p className="text-gray-400">공정한 야구 티켓 예매 플랫폼</p>
            </div>
            <div>
              <h4 className="font-bold mb-4">서비스</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <a href="#" className="hover:text-white">
                    티켓 예매
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    구단 순위
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    선수 기록
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    경기 일정
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">고객지원</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <a href="#" className="hover:text-white">
                    FAQ
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    고객센터
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    환불정책
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    이용약관
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">회사정보</h4>
              <ul className="space-y-2 text-gray-400">
                <li>서울시 강남구</li>
                <li>고객센터: 1588-0000</li>
                <li>이메일: info@time-pitch.com</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Time-Pitch. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
