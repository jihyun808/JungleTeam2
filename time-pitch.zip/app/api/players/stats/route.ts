import { NextResponse } from "next/server"

// KBO 선수 개인 성적 데이터
const playerStats = {
  batting: [
    { name: "최형우", team: "KIA", position: "외야수", avg: 0.348, hr: 31, rbi: 109, sb: 8 },
    { name: "소크라테스", team: "KIA", position: "내야수", avg: 0.326, hr: 31, rbi: 98, sb: 2 },
    { name: "나성범", team: "KIA", position: "외야수", avg: 0.324, hr: 28, rbi: 109, sb: 15 },
    { name: "윤영철", team: "LG", position: "내야수", avg: 0.318, hr: 12, rbi: 67, sb: 36 },
    { name: "김도영", team: "KIA", position: "내야수", avg: 0.347, hr: 37, rbi: 109, sb: 5 },
  ],
  pitching: [
    { name: "페디", team: "KIA", position: "투수", wins: 20, losses: 8, era: 2.0, strikeouts: 194 },
    { name: "원태인", team: "삼성", position: "투수", wins: 13, losses: 6, era: 2.54, strikeouts: 163 },
    { name: "임찬규", team: "LG", position: "투수", wins: 15, losses: 7, era: 2.78, strikeouts: 152 },
    { name: "곽빈", team: "두산", position: "투수", wins: 12, losses: 9, era: 3.12, strikeouts: 141 },
    { name: "엔스", team: "LG", position: "투수", wins: 11, losses: 8, era: 3.24, strikeouts: 138 },
  ],
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get("category") || "batting"

    // 실제 환경에서는 여기서 KBO 공식 사이트를 스크래핑
    // const scrapedData = await scrapeKBOPlayerStats(category)

    const data = category === "pitching" ? playerStats.pitching : playerStats.batting

    return NextResponse.json({
      success: true,
      data,
      category,
      lastUpdated: new Date().toISOString(),
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to fetch player stats" }, { status: 500 })
  }
}
