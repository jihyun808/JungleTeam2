import { NextResponse } from "next/server"

// KBO 구단 순위 데이터 (실제로는 스크래핑으로 가져올 데이터)
const teamRankings = [
  { rank: 1, team: "KIA 타이거즈", wins: 87, losses: 55, draws: 2, games: 144, winRate: 0.613 },
  { rank: 2, team: "삼성 라이온즈", wins: 81, losses: 61, draws: 2, games: 144, winRate: 0.57 },
  { rank: 3, team: "LG 트윈스", wins: 79, losses: 63, draws: 2, games: 144, winRate: 0.556 },
  { rank: 4, team: "두산 베어스", wins: 76, losses: 66, draws: 2, games: 144, winRate: 0.535 },
  { rank: 5, team: "KT 위즈", wins: 72, losses: 70, draws: 2, games: 144, winRate: 0.507 },
  { rank: 6, team: "SSG 랜더스", wins: 70, losses: 72, draws: 2, games: 144, winRate: 0.493 },
  { rank: 7, team: "롯데 자이언츠", wins: 66, losses: 76, draws: 2, games: 144, winRate: 0.465 },
  { rank: 8, team: "한화 이글스", wins: 64, losses: 78, draws: 2, games: 144, winRate: 0.451 },
  { rank: 9, team: "키움 히어로즈", wins: 62, losses: 80, draws: 2, games: 144, winRate: 0.437 },
  { rank: 10, team: "NC 다이노스", wins: 57, losses: 85, draws: 2, games: 144, winRate: 0.401 },
]

export async function GET() {
  try {
    // 실제 환경에서는 여기서 KBO 공식 사이트를 스크래핑
    // const scrapedData = await scrapeKBOTeamRankings()

    return NextResponse.json({
      success: true,
      data: teamRankings,
      lastUpdated: new Date().toISOString(),
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to fetch team rankings" }, { status: 500 })
  }
}
