import { NextResponse } from "next/server"

// 오늘의 경기 일정 데이터
const todayGames = [
  {
    id: 1,
    home: "KIA 타이거즈",
    away: "삼성 라이온즈",
    time: "18:30",
    stadium: "광주-기아 챔피언스 필드",
    date: new Date().toISOString().split("T")[0],
    status: "scheduled",
    ticketAvailable: true,
  },
  {
    id: 2,
    home: "LG 트윈스",
    away: "두산 베어스",
    time: "18:30",
    stadium: "잠실야구장",
    date: new Date().toISOString().split("T")[0],
    status: "scheduled",
    ticketAvailable: true,
  },
  {
    id: 3,
    home: "한화 이글스",
    away: "롯데 자이언츠",
    time: "18:30",
    stadium: "대전한화생명이글스파크",
    date: new Date().toISOString().split("T")[0],
    status: "scheduled",
    ticketAvailable: false,
  },
  {
    id: 4,
    home: "SSG 랜더스",
    away: "키움 히어로즈",
    time: "18:30",
    stadium: "인천SSG랜더스필드",
    date: new Date().toISOString().split("T")[0],
    status: "scheduled",
    ticketAvailable: true,
  },
  {
    id: 5,
    home: "KT 위즈",
    away: "NC 다이노스",
    time: "18:30",
    stadium: "수원KT위즈파크",
    date: new Date().toISOString().split("T")[0],
    status: "scheduled",
    ticketAvailable: true,
  },
]

export async function GET() {
  try {
    // 실제 환경에서는 여기서 KBO 공식 사이트를 스크래핑
    // const scrapedData = await scrapeKBOTodayGames()

    return NextResponse.json({
      success: true,
      data: todayGames,
      lastUpdated: new Date().toISOString(),
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to fetch today games" }, { status: 500 })
  }
}
