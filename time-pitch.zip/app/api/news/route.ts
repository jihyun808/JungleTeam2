import { NextResponse } from "next/server"

const kboNews = [
  {
    id: 1,
    title: "KIA 타이거즈, 정규시즌 1위 확정",
    summary:
      "KIA가 2024 정규시즌 1위를 확정지으며 플레이오프 직행권을 획득했다. 팀은 뛰어난 타선과 안정적인 투수진을 바탕으로 시즌 내내 선두를 유지했다.",
    content: "KIA 타이거즈가 2024 KBO 정규시즌 1위를 확정했다...",
    publishedAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), // 2시간 전
    source: "스포츠조선",
    url: "https://sports.chosun.com/news/kbo/kia-tigers-first-place",
    imageUrl: "/kia-tigers-celebration.png",
    category: "팀뉴스",
  },
  {
    id: 2,
    title: "최형우, 개인 통산 2000안타 달성",
    summary:
      "KIA 최형우가 개인 통산 2000안타를 달성하며 새로운 기록을 세웠다. 그는 KBO 리그 역사상 가장 빠른 속도로 이 기록을 달성했다.",
    content: "KIA 타이거즈의 최형우가 통산 2000안타를 달성했다...",
    publishedAt: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(), // 4시간 전
    source: "OSEN",
    url: "https://osen.mt.co.kr/article/choi-hyung-woo-2000-hits",
    imageUrl: "/baseball-milestone.png",
    category: "선수기록",
  },
  {
    id: 3,
    title: "2024 포스트시즌 일정 발표",
    summary: "KBO가 2024 포스트시즌 일정을 공식 발표했다. 와일드카드 결정전부터 한국시리즈까지의 전체 일정이 확정됐다.",
    content: "KBO가 2024 포스트시즌 일정을 발표했다...",
    publishedAt: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(), // 6시간 전
    source: "MBC스포츠플러스",
    url: "https://mbcsportsplus.com/news/postseason-schedule-2024",
    imageUrl: "/baseball-postseason-announcement.png",
    category: "리그소식",
  },
  {
    id: 4,
    title: "페디, 20승 달성으로 최다승 1위",
    summary:
      "KIA의 외국인 투수 페디가 시즌 20승을 달성하며 최다승 1위에 올랐다. 그는 팀의 정규시즌 1위 확정에 크게 기여했다.",
    content: "KIA 타이거즈의 페디가 시즌 20승을 달성했다...",
    publishedAt: new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString(), // 8시간 전
    source: "일간스포츠",
    url: "https://isplus.live.joins.com/news/pedi-20-wins-leader",
    imageUrl: "/baseball-pitcher-victory.png",
    category: "선수기록",
  },
  {
    id: 5,
    title: "김도영, 신인왕 유력 후보로 급부상",
    summary:
      "KIA의 신인 김도영이 뛰어난 활약을 펼치며 신인왕 후보로 급부상했다. 그는 타율과 장타력 모든 면에서 인상적인 성과를 보이고 있다.",
    content: "KIA 타이거즈의 신인 김도영이 신인왕 후보로 주목받고 있다...",
    publishedAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(), // 12시간 전
    source: "스포츠서울",
    url: "https://sportsseoul.com/news/kim-do-young-rookie-award",
    imageUrl: "/young-baseball-rookie.png",
    category: "선수기록",
  },
  {
    id: 6,
    title: "잠실야구장, 플레이오프 대비 시설 점검",
    summary:
      "잠실야구장이 다가오는 플레이오프를 대비해 전면적인 시설 점검에 들어갔다. 관중석과 조명, 전광판 등 모든 시설을 점검하고 있다.",
    content: "잠실야구장이 플레이오프 준비에 만전을 기하고 있다...",
    publishedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(), // 1일 전
    source: "스포츠동아",
    url: "https://sports.donga.com/news/jamsil-stadium-playoff-preparation",
    imageUrl: "/baseball-stadium-maintenance.png",
    category: "구장소식",
  },
  {
    id: 7,
    title: "삼성 라이온즈, 2위 확정으로 플레이오프 진출",
    summary:
      "삼성 라이온즈가 정규시즌 2위를 확정하며 플레이오프 직행권을 획득했다. 팀은 시즌 후반 강력한 상승세를 보였다.",
    content: "삼성 라이온즈가 정규시즌 2위를 확정했다...",
    publishedAt: new Date(Date.now() - 1.5 * 24 * 60 * 60 * 1000).toISOString(),
    source: "스포츠조선",
    url: "https://sports.chosun.com/news/samsung-lions-second-place",
    imageUrl: "/samsung-lions-celebration.png",
    category: "팀뉴스",
  },
  {
    id: 8,
    title: "LG 트윈스 vs 두산 베어스, 잠실 더비 화제",
    summary:
      "LG 트윈스와 두산 베어스의 잠실 더비가 팬들의 뜨거운 관심을 받고 있다. 양 팀 모두 플레이오프 진출을 위해 치열한 경쟁을 벌이고 있다.",
    content: "잠실야구장에서 펼쳐지는 LG와 두산의 더비 매치...",
    publishedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    source: "OSEN",
    url: "https://osen.mt.co.kr/article/lg-doosan-jamsil-derby",
    imageUrl: "/placeholder-ospo8.png",
    category: "경기소식",
  },
  {
    id: 9,
    title: "한화 이글스, 신인 투수 발굴에 성공",
    summary:
      "한화 이글스가 새로운 신인 투수를 발굴해 화제가 되고 있다. 이 선수는 뛰어난 구속과 제구력을 보여주며 팀의 미래 에이스로 기대받고 있다.",
    content: "한화 이글스의 새로운 신인 투수가 주목받고 있다...",
    publishedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    source: "MBC스포츠플러스",
    url: "https://mbcsportsplus.com/news/hanwha-eagles-rookie-pitcher",
    imageUrl: "/young-baseball-pitcher.png",
    category: "선수기록",
  },
  {
    id: 10,
    title: "롯데 자이언츠, 팬 서비스 확대 발표",
    summary:
      "롯데 자이언츠가 팬들을 위한 다양한 서비스 확대 계획을 발표했다. 새로운 팬클럽 혜택과 경기장 편의시설 개선이 포함되어 있다.",
    content: "롯데 자이언츠가 팬 서비스 확대를 발표했다...",
    publishedAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
    source: "일간스포츠",
    url: "https://isplus.live.joins.com/news/lotte-giants-fan-service",
    imageUrl: "/baseball-fans-cheering.png",
    category: "팀뉴스",
  },
  {
    id: 11,
    title: "KT 위즈, 외국인 선수 영입 검토",
    summary:
      "KT 위즈가 내년 시즌을 대비해 새로운 외국인 선수 영입을 검토하고 있다고 발표했다. 특히 타선 보강에 중점을 두고 있다.",
    content: "KT 위즈가 외국인 선수 영입을 검토하고 있다...",
    publishedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    source: "스포츠서울",
    url: "https://sportsseoul.com/news/kt-wiz-foreign-player-recruitment",
    imageUrl: "/baseball-management-meeting.png",
    category: "이적소식",
  },
  {
    id: 12,
    title: "SSG 랜더스, 홈구장 시설 업그레이드",
    summary:
      "SSG 랜더스가 인천SSG랜더스필드의 시설 업그레이드를 진행한다고 발표했다. 관중 편의시설과 선수 훈련시설이 대폭 개선될 예정이다.",
    content: "SSG 랜더스가 홈구장 시설 업그레이드를 진행한다...",
    publishedAt: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000).toISOString(),
    source: "스포츠동아",
    url: "https://sports.donga.com/news/ssg-landers-stadium-upgrade",
    imageUrl: "/modern-baseball-stadium-renovation.png",
    category: "구장소식",
  },
]

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const limit = Number.parseInt(searchParams.get("limit") || "6")
    const category = searchParams.get("category")
    const search = searchParams.get("search")

    let filteredNews = [...kboNews]

    if (category && category !== "all") {
      filteredNews = filteredNews.filter((news) => news.category === category)
    }

    if (search) {
      const searchTerm = search.toLowerCase()
      filteredNews = filteredNews.filter(
        (news) =>
          news.title.toLowerCase().includes(searchTerm) ||
          news.summary.toLowerCase().includes(searchTerm) ||
          news.source.toLowerCase().includes(searchTerm),
      )
    }

    // 실제 환경에서는 여기서 KBO 관련 뉴스 사이트들을 스크래핑
    // const scrapedNews = await scrapeKBONews()

    const limitedNews = filteredNews.slice(0, limit)

    return NextResponse.json({
      success: true,
      data: limitedNews,
      total: filteredNews.length,
      lastUpdated: new Date().toISOString(),
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to fetch news" }, { status: 500 })
  }
}
