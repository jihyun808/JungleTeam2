"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Clock, MapPin, Users, Ticket, AlertCircle } from "lucide-react"
import { useEffect, useState } from "react"
import Link from "next/link"

interface Game {
  id: number
  home: string
  away: string
  time: string
  stadium: string
  date: string
  status: string
  ticketAvailable: boolean
}

interface SeatSection {
  id: string
  name: string
  price: number
  availableSeats: number
  totalSeats: number
  nextAvailableTime?: string
  isAvailable: boolean
}

interface SelectedSeat {
  section: string
  row: string
  seat: string
  price: number
}

export default function BookingPage() {
  const [games, setGames] = useState<Game[]>([])
  const [selectedGame, setSelectedGame] = useState<Game | null>(null)
  const [seatSections, setSeatSections] = useState<SeatSection[]>([])
  const [selectedSeats, setSelectedSeats] = useState<SelectedSeat[]>([])
  const [currentStep, setCurrentStep] = useState<"game" | "seat" | "confirm">("game")
  const [loading, setLoading] = useState(true)

  // 좌석 구역 데이터
  const sectionData: SeatSection[] = [
    { id: "premium", name: "프리미엄석", price: 45000, availableSeats: 120, totalSeats: 150, isAvailable: true },
    { id: "box", name: "박스석", price: 35000, availableSeats: 80, totalSeats: 200, isAvailable: true },
    {
      id: "table",
      name: "테이블석",
      price: 30000,
      availableSeats: 0,
      totalSeats: 100,
      nextAvailableTime: "19:35",
      isAvailable: false,
    },
    { id: "infield", name: "내야석", price: 25000, availableSeats: 450, totalSeats: 800, isAvailable: true },
    { id: "outfield", name: "외야석", price: 18000, availableSeats: 320, totalSeats: 600, isAvailable: true },
    {
      id: "bleacher",
      name: "블리처석",
      price: 12000,
      availableSeats: 0,
      totalSeats: 400,
      nextAvailableTime: "19:40",
      isAvailable: false,
    },
  ]

  useEffect(() => {
    const fetchGames = async () => {
      try {
        const response = await fetch("/api/games/today")
        const data = await response.json()
        if (data.success) {
          setGames(data.data)
        }
      } catch (error) {
        console.error("Failed to fetch games:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchGames()
    setSeatSections(sectionData)
  }, [])

  const handleGameSelect = (game: Game) => {
    setSelectedGame(game)
    setCurrentStep("seat")
  }

  const handleSeatSelect = (section: SeatSection, row: string, seat: string) => {
    if (!section.isAvailable) return

    const seatId = `${section.id}-${row}-${seat}`
    const existingSeat = selectedSeats.find((s) => `${s.section}-${s.row}-${s.seat}` === seatId)

    if (existingSeat) {
      setSelectedSeats(selectedSeats.filter((s) => `${s.section}-${s.row}-${s.seat}` !== seatId))
    } else {
      if (selectedSeats.length < 4) {
        setSelectedSeats([
          ...selectedSeats,
          {
            section: section.id,
            row,
            seat,
            price: section.price,
          },
        ])
      }
    }
  }

  const getTotalPrice = () => {
    return selectedSeats.reduce((total, seat) => total + seat.price, 0)
  }

  const formatPrice = (price: number) => {
    return price.toLocaleString("ko-KR") + "원"
  }

  const renderSeatMap = (section: SeatSection) => {
    const rows = ["A", "B", "C", "D", "E"]
    const seatsPerRow = 10

    return (
      <div className="grid grid-cols-10 gap-1 p-4 bg-gray-50 rounded-lg">
        {rows.map((row) =>
          Array.from({ length: seatsPerRow }, (_, seatIndex) => {
            const seatNumber = (seatIndex + 1).toString()
            const seatId = `${section.id}-${row}-${seatNumber}`
            const isSelected = selectedSeats.some((s) => `${s.section}-${s.row}-${s.seat}` === seatId)
            const isOccupied = Math.random() > 0.7 // 임시로 30% 확률로 점유된 좌석

            return (
              <button
                key={seatId}
                onClick={() => handleSeatSelect(section, row, seatNumber)}
                disabled={!section.isAvailable || isOccupied}
                className={`
                  w-8 h-8 text-xs rounded border-2 transition-colors
                  ${
                    isSelected
                      ? "bg-blue-600 text-white border-blue-600"
                      : isOccupied
                        ? "bg-gray-300 text-gray-500 border-gray-300 cursor-not-allowed"
                        : section.isAvailable
                          ? "bg-white text-gray-700 border-gray-300 hover:border-blue-400 hover:bg-blue-50"
                          : "bg-red-100 text-red-400 border-red-200 cursor-not-allowed"
                  }
                `}
              >
                {row}
                {seatNumber}
              </button>
            )
          }),
        )}
      </div>
    )
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>경기 정보를 불러오는 중...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  홈으로
                </Button>
              </Link>
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                  <Ticket className="w-5 h-5 text-white" />
                </div>
                <h1 className="text-2xl font-bold text-blue-600">Time-Pitch</h1>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant={currentStep === "game" ? "default" : "secondary"}>1. 경기선택</Badge>
              <Badge variant={currentStep === "seat" ? "default" : "secondary"}>2. 좌석선택</Badge>
              <Badge variant={currentStep === "confirm" ? "default" : "secondary"}>3. 예매확인</Badge>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Game Selection */}
        {currentStep === "game" && (
          <div>
            <h2 className="text-3xl font-bold mb-8 text-center">경기를 선택해주세요</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
              {games.map((game) => (
                <Card
                  key={game.id}
                  className={`cursor-pointer transition-all hover:shadow-lg ${
                    !game.ticketAvailable ? "opacity-50" : "hover:border-blue-300"
                  }`}
                  onClick={() => game.ticketAvailable && handleGameSelect(game)}
                >
                  <CardContent className="p-6">
                    <div className="text-center mb-4">
                      <div className="text-sm text-gray-500 mb-2 flex items-center justify-center">
                        <Clock className="w-4 h-4 mr-1" />
                        {game.time}
                      </div>
                      <div className="text-xl font-bold mb-2">
                        {game.away} vs {game.home}
                      </div>
                      <div className="text-sm text-gray-600 flex items-center justify-center">
                        <MapPin className="w-4 h-4 mr-1" />
                        {game.stadium}
                      </div>
                    </div>
                    <Button
                      className="w-full"
                      disabled={!game.ticketAvailable}
                      variant={game.ticketAvailable ? "default" : "secondary"}
                    >
                      {game.ticketAvailable ? "좌석 선택하기" : "매진"}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Seat Selection */}
        {currentStep === "seat" && selectedGame && (
          <div>
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold mb-2">좌석을 선택해주세요</h2>
              <p className="text-gray-600">
                {selectedGame.away} vs {selectedGame.home} | {selectedGame.time} | {selectedGame.stadium}
              </p>
            </div>

            {/* 구역별 5분 간격 안내 */}
            <Card className="mb-8 bg-blue-50 border-blue-200">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div>
                    <h3 className="font-bold text-blue-900 mb-1">공정한 예매 시스템</h3>
                    <p className="text-blue-800 text-sm">
                      구역별로 5분 간격을 두고 예매가 시작됩니다. 암표와 몰림 현상을 방지하여 모든 팬이 공정하게 티켓을
                      구매할 수 있습니다.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* 좌석 구역 선택 */}
              <div className="lg:col-span-1">
                <Card>
                  <CardHeader>
                    <CardTitle>구역 선택</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {seatSections.map((section) => (
                        <div
                          key={section.id}
                          className={`p-4 rounded-lg border-2 transition-colors ${
                            section.isAvailable
                              ? "border-gray-200 hover:border-blue-300 cursor-pointer"
                              : "border-red-200 bg-red-50"
                          }`}
                        >
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <h3 className="font-bold">{section.name}</h3>
                              <p className="text-lg font-bold text-blue-600">{formatPrice(section.price)}</p>
                            </div>
                            <Badge variant={section.isAvailable ? "default" : "destructive"}>
                              {section.isAvailable ? "예매가능" : "대기중"}
                            </Badge>
                          </div>
                          <div className="text-sm text-gray-600">
                            <div className="flex items-center gap-2 mb-1">
                              <Users className="w-4 h-4" />
                              잔여석: {section.availableSeats}/{section.totalSeats}
                            </div>
                            {!section.isAvailable && section.nextAvailableTime && (
                              <div className="flex items-center gap-2 text-red-600">
                                <Clock className="w-4 h-4" />
                                {section.nextAvailableTime} 예매 시작
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* 좌석 맵 */}
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle>좌석 배치도</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {seatSections
                        .filter((s) => s.isAvailable)
                        .map((section) => (
                          <div key={section.id}>
                            <h3 className="font-bold mb-3 flex items-center justify-between">
                              <span>{section.name}</span>
                              <span className="text-sm text-gray-600">{formatPrice(section.price)}</span>
                            </h3>
                            {renderSeatMap(section)}
                          </div>
                        ))}
                    </div>

                    {/* 범례 */}
                    <div className="mt-6 flex items-center justify-center gap-6 text-sm">
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 bg-white border-2 border-gray-300 rounded"></div>
                        <span>선택가능</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 bg-blue-600 border-2 border-blue-600 rounded"></div>
                        <span>선택됨</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 bg-gray-300 border-2 border-gray-300 rounded"></div>
                        <span>선택불가</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* 선택된 좌석 및 결제 */}
            {selectedSeats.length > 0 && (
              <Card className="mt-8 bg-green-50 border-green-200">
                <CardContent className="p-6">
                  <h3 className="font-bold mb-4">선택된 좌석</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      {selectedSeats.map((seat, index) => (
                        <div key={index} className="flex justify-between items-center py-2">
                          <span>
                            {seat.section.toUpperCase()} {seat.row}열 {seat.seat}번
                          </span>
                          <span className="font-bold">{formatPrice(seat.price)}</span>
                        </div>
                      ))}
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-green-600">총 {formatPrice(getTotalPrice())}</div>
                      <p className="text-sm text-gray-600">선택된 좌석: {selectedSeats.length}개</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <Button variant="outline" onClick={() => setCurrentStep("game")} className="flex-1">
                      경기 다시 선택
                    </Button>
                    <Button
                      onClick={() => setCurrentStep("confirm")}
                      className="flex-1 bg-green-600 hover:bg-green-700"
                    >
                      예매 진행하기
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {/* Booking Confirmation */}
        {currentStep === "confirm" && selectedGame && selectedSeats.length > 0 && (
          <div className="max-w-2xl mx-auto">
            <h2 className="text-3xl font-bold mb-8 text-center">예매 확인</h2>

            <Card className="mb-6">
              <CardHeader>
                <CardTitle>경기 정보</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>경기:</span>
                    <span className="font-bold">
                      {selectedGame.away} vs {selectedGame.home}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>일시:</span>
                    <span>
                      {selectedGame.date} {selectedGame.time}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>장소:</span>
                    <span>{selectedGame.stadium}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="mb-6">
              <CardHeader>
                <CardTitle>선택된 좌석</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {selectedSeats.map((seat, index) => (
                    <div key={index} className="flex justify-between">
                      <span>
                        {seat.section.toUpperCase()} {seat.row}열 {seat.seat}번
                      </span>
                      <span className="font-bold">{formatPrice(seat.price)}</span>
                    </div>
                  ))}
                  <div className="border-t pt-2 mt-4">
                    <div className="flex justify-between text-lg font-bold">
                      <span>총 결제금액:</span>
                      <span className="text-blue-600">{formatPrice(getTotalPrice())}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="flex gap-4">
              <Button variant="outline" onClick={() => setCurrentStep("seat")} className="flex-1">
                좌석 다시 선택
              </Button>
              <Button className="flex-1 bg-blue-600 hover:bg-blue-700">결제하기</Button>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}
