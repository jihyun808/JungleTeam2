import type React from "react"
import type { Metadata } from "next"
import { GeistSans } from "geist/font/sans"
import { GeistMono } from "geist/font/mono"
import "./globals.css"

export const metadata: Metadata = {
  title: "Time-Pitch - 공정한 야구 티켓 예매",
  description:
    "구역별 5분 간격 예매로 암표와 몰림 현상을 방지하는 혁신적인 야구 티켓팅 플랫폼. 진정한 야구 팬을 위한 공정한 예매 시스템을 경험하세요.",
  generator: "v0.app",
  keywords: "야구 티켓, KBO 예매, 암표 방지, 공정한 티켓팅, Time-Pitch",
  openGraph: {
    title: "Time-Pitch - 공정한 야구 티켓 예매",
    description: "구역별 5분 간격 예매로 암표와 몰림 현상을 방지하는 혁신적인 야구 티켓팅 플랫폼",
    type: "website",
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="ko">
      <head>
        <style>{`
html {
  font-family: ${GeistSans.style.fontFamily};
  --font-sans: ${GeistSans.variable};
  --font-mono: ${GeistMono.variable};
}
        `}</style>
      </head>
      <body>{children}</body>
    </html>
  )
}
